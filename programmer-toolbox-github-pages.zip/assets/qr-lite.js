(function () {
  const DATA_CODEWORDS = [0, 19, 34, 55, 80, 108];
  const ECC_CODEWORDS = [0, 7, 10, 15, 20, 26];
  const ALIGNMENT = { 1: [], 2: [6, 18], 3: [6, 22], 4: [6, 26], 5: [6, 30] };
  const FORMAT_L_MASK0 = 0b111011111000100;

  const gfExp = new Array(512);
  const gfLog = new Array(256);
  let x = 1;
  for (let i = 0; i < 255; i += 1) {
    gfExp[i] = x;
    gfLog[x] = i;
    x <<= 1;
    if (x & 0x100) x ^= 0x11d;
  }
  for (let i = 255; i < 512; i += 1) gfExp[i] = gfExp[i - 255];

  function gfMul(a, b) {
    return a && b ? gfExp[gfLog[a] + gfLog[b]] : 0;
  }

  function rsGenerator(degree) {
    let poly = [1];
    for (let i = 0; i < degree; i += 1) {
      const next = new Array(poly.length + 1).fill(0);
      for (let j = 0; j < poly.length; j += 1) {
        next[j] ^= gfMul(poly[j], gfExp[i]);
        next[j + 1] ^= poly[j];
      }
      poly = next;
    }
    return poly.slice(1);
  }

  function rsRemainder(data, degree) {
    const gen = rsGenerator(degree);
    const rem = new Array(degree).fill(0);
    data.forEach((value) => {
      const factor = value ^ rem.shift();
      rem.push(0);
      for (let i = 0; i < degree; i += 1) rem[i] ^= gfMul(gen[i], factor);
    });
    return rem;
  }

  function pushBits(bits, value, length) {
    for (let i = length - 1; i >= 0; i -= 1) bits.push((value >>> i) & 1);
  }

  function bytesToDataCodewords(bytes, version) {
    const capacity = DATA_CODEWORDS[version];
    const bits = [];
    pushBits(bits, 0b0100, 4);
    pushBits(bits, bytes.length, 8);
    bytes.forEach((byte) => pushBits(bits, byte, 8));
    const maxBits = capacity * 8;
    pushBits(bits, 0, Math.min(4, maxBits - bits.length));
    while (bits.length % 8) bits.push(0);
    const data = [];
    for (let i = 0; i < bits.length; i += 8) {
      data.push(bits.slice(i, i + 8).reduce((acc, bit) => (acc << 1) | bit, 0));
    }
    for (let pad = 0xec; data.length < capacity; pad ^= 0xec ^ 0x11) data.push(pad);
    return data;
  }

  function chooseVersion(bytes) {
    for (let version = 1; version <= 5; version += 1) {
      if (bytes.length <= DATA_CODEWORDS[version] - 2) return version;
    }
    throw new Error('单条二维码内容过长，请控制在约 100 个英文字符以内');
  }

  function makeMatrix(version) {
    const size = version * 4 + 17;
    const modules = Array.from({ length: size }, () => new Array(size).fill(false));
    const reserved = Array.from({ length: size }, () => new Array(size).fill(false));

    function set(x, y, dark, reserve = true) {
      if (x < 0 || y < 0 || x >= size || y >= size) return;
      modules[y][x] = !!dark;
      if (reserve) reserved[y][x] = true;
    }

    function finder(left, top) {
      for (let y = -1; y <= 7; y += 1) {
        for (let x = -1; x <= 7; x += 1) {
          const xx = left + x;
          const yy = top + y;
          const dark = x >= 0 && x <= 6 && y >= 0 && y <= 6 && (x === 0 || x === 6 || y === 0 || y === 6 || (x >= 2 && x <= 4 && y >= 2 && y <= 4));
          set(xx, yy, dark);
        }
      }
    }

    function alignment(cx, cy) {
      for (let y = -2; y <= 2; y += 1) {
        for (let x = -2; x <= 2; x += 1) {
          set(cx + x, cy + y, Math.max(Math.abs(x), Math.abs(y)) !== 1);
        }
      }
    }

    finder(0, 0);
    finder(size - 7, 0);
    finder(0, size - 7);
    for (let i = 8; i < size - 8; i += 1) {
      set(6, i, i % 2 === 0);
      set(i, 6, i % 2 === 0);
    }
    (ALIGNMENT[version] || []).forEach((cy) => {
      (ALIGNMENT[version] || []).forEach((cx) => {
        if (!reserved[cy][cx]) alignment(cx, cy);
      });
    });
    set(8, version * 4 + 9, true);

    for (let i = 0; i < 9; i += 1) {
      if (i !== 6) {
        set(8, i, false);
        set(i, 8, false);
      }
    }
    for (let i = 0; i < 8; i += 1) {
      set(size - 1 - i, 8, false);
      set(8, size - 1 - i, false);
    }
    return { modules, reserved, size, set };
  }

  function drawFormat(qr) {
    for (let i = 0; i <= 5; i += 1) qr.set(8, i, (FORMAT_L_MASK0 >>> i) & 1);
    qr.set(8, 7, (FORMAT_L_MASK0 >>> 6) & 1);
    qr.set(8, 8, (FORMAT_L_MASK0 >>> 7) & 1);
    qr.set(7, 8, (FORMAT_L_MASK0 >>> 8) & 1);
    for (let i = 9; i < 15; i += 1) qr.set(14 - i, 8, (FORMAT_L_MASK0 >>> i) & 1);
    for (let i = 0; i < 8; i += 1) qr.set(qr.size - 1 - i, 8, (FORMAT_L_MASK0 >>> i) & 1);
    for (let i = 8; i < 15; i += 1) qr.set(8, qr.size - 15 + i, (FORMAT_L_MASK0 >>> i) & 1);
  }

  function placeData(qr, codewords) {
    const bits = [];
    codewords.forEach((byte) => pushBits(bits, byte, 8));
    let bitIndex = 0;
    let upward = true;
    for (let right = qr.size - 1; right >= 1; right -= 2) {
      if (right === 6) right -= 1;
      for (let vert = 0; vert < qr.size; vert += 1) {
        const y = upward ? qr.size - 1 - vert : vert;
        for (let j = 0; j < 2; j += 1) {
          const x = right - j;
          if (qr.reserved[y][x]) continue;
          let bit = bitIndex < bits.length ? bits[bitIndex] : 0;
          bitIndex += 1;
          if ((x + y) % 2 === 0) bit ^= 1;
          qr.modules[y][x] = !!bit;
        }
      }
      upward = !upward;
    }
  }

  function toSvgDataUrl(qr) {
    const quiet = 4;
    const scale = 8;
    const size = (qr.size + quiet * 2) * scale;
    const rects = [];
    for (let y = 0; y < qr.size; y += 1) {
      for (let x = 0; x < qr.size; x += 1) {
        if (qr.modules[y][x]) rects.push(`<rect x="${(x + quiet) * scale}" y="${(y + quiet) * scale}" width="${scale}" height="${scale}"/>`);
      }
    }
    const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 ${size} ${size}"><rect width="100%" height="100%" fill="#fff"/><g fill="#000">${rects.join('')}</g></svg>`;
    return `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;
  }

  window.makeQrDataUrl = function makeQrDataUrl(value) {
    const bytes = Array.from(new TextEncoder().encode(String(value)));
    const version = chooseVersion(bytes);
    const data = bytesToDataCodewords(bytes, version);
    const ecc = rsRemainder(data, ECC_CODEWORDS[version]);
    const qr = makeMatrix(version);
    placeData(qr, data.concat(ecc));
    drawFormat(qr);
    return toSvgDataUrl(qr);
  };
})();
